
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p1 = new Person("Puja",20);
		Account ac = new Account(234,2000,"Puja");
	}

}
