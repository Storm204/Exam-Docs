package snippet;

import org.openqa.selenium.firefox.FirefoxDriver;



 
public class WorkingWithForms 
{
	public static void main(String[] args) 
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html");
		driver.findElement(By.id("txtUserName")).submit();
		
	}
}
