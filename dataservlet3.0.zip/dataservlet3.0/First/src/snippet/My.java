package snippet;

import org.openqa.selenium.WebDriver;

public class My {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
WebDriver driver=new FirefoxDriver();
	}

}
