package snippet;

public class Snippet {
	public static void main(String[] args) {
		D:\Users\ADM-IG-HWDLAB1B\Desktop\junit-4.6.jar
	}
}

