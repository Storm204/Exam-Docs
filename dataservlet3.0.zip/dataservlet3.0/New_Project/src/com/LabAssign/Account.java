package com.LabAssign;

public class Account {

}
