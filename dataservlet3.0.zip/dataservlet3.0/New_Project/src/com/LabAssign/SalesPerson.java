package com.LabAssign;

public class SalesPerson extends Manager {

	int rate;	double hours;
	
	public SalesPerson(int empId, String empname,String dept,double hours, int d) {
	super(empId, empname, dept);
	this.rate = d;
	this.hours = hours;
}

	public double Calc_Sal()
	{
		return(rate*hours);
	}

	@Override
	public String toString() {
		return super.toString()+"\n"+"SalesPerson [rate=" + rate + ", hours=" + hours + "]";
	}

	@Override
	public String getEmpname() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
