package com.LabAssign;

public class Employee {


	
	public int empId;
	public String Empname;
	
	
	
	public Employee(int empId, String empname) {
		super();
		this.empId = empId;
		this.Empname = empname;
	}

	


	public String toString() {
		return "Employee empId=" + empId + ", Empname=" + Empname;
	}

	public double calc_sal() {
		return 0;
	}

	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpname() {
		return Empname;
	}


	public void setEmpname(String empname) {
		Empname = empname;
	}

	
	
}
