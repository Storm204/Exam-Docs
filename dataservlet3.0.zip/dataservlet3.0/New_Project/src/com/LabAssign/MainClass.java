package com.LabAssign;

import java.util.*;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee m1 = new SalesPerson(1,"puja","HR",3,1000);
		Employee m2 = new SalesPerson(2,"Pratibha","Finance",4,2000);
		Employee m3 = new SalesPerson(3,"Chinmin","HR",2,100);
		
		HashSet al = new HashSet();
		al.add(m1);
		al.add(m2);
		al.add(m3);
		
		System.out.println(al);
	}

}
