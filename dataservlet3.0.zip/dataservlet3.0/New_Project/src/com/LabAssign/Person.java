package com.LabAssign;

public class Person {

	private String firstName;
	private String lastName;
	private char gender;
	
	public Person() {
		super();
	}

	public Person(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	
	public void disp(){
		System.out.println("Personal Details");
		System.out.println("------------------");
		System.out.println("First Name :" +firstName);
		System.out.println("First Name :" +lastName);
		System.out.println("Gender :" +gender);
	}
}
