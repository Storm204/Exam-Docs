package com.LabAssign;

public class Manager extends Employee {
	
	public String dept;
	
	
	public Manager(int empId, String empname, String dept) {
		super(empId, empname);
		this.dept=dept;
		// TODO Auto-generated constructor stub
	}

	public double calc_sal(){
		return (1000.00d);
		
	}

	@Override
	public String toString() {
		return super.toString()+", dept=" + dept;
	}

	public String getDept() {
		return dept;
	}

public void setDept(String dept) {
		this.dept = dept;
	}

public String getEmpname() {
	// TODO Auto-generated method stub
	return null;
}

	
	

}
