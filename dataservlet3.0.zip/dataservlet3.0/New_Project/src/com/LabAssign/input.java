package com.LabAssign;

public interface input {

	default void hello()
	{
		System.out.println("Hello");
	}
	
	public static void main(String args[]){
		System.out.println("Hello1");
	}
}
