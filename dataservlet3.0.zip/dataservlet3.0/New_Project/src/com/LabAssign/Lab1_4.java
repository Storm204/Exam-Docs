package com.LabAssign;

public class Lab1_4 {

	public static void main(String s[])
	{
		System.out.println("Personal Details");
		System.out.println("------------------");
		System.out.println("First Name : Divya");
		System.out.println("Last Name : Bharathi");
		System.out.println("Gender : F");
		System.out.println("Age : 20");
		System.out.println("Weight : 85.55");
	}
}
