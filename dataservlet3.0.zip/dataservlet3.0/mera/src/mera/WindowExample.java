package mera;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WindowExample 
{

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/PopupWin.html");
		String parentWindow = driver.getWindowHandle().toString();
		Thread.sleep(3000);
		driver.findElement(By.name("Open")).click();
		Thread.sleep(3000);
		driver.switchTo().window("PopupWindow");
		Thread.sleep(3000);
		driver.close();
		Thread.sleep(3000);
		driver.switchTo().window(parentWindow);
		Thread.sleep(3000);
		driver.close();
	}

}
