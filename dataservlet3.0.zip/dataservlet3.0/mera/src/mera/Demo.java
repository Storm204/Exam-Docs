package mera;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Demo 
{

	public static void main(String[] args) throws Exception 
	{
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html");
		driver.findElement(By.name("txtUName")).sendKeys("John");
		Thread.sleep(3000);
		driver.findElement(By.name("submit")).submit();
		System.out.println(driver.getTitle());
		driver.navigate().to("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/Demo.html");
		driver.navigate().refresh();
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
		driver.navigate().forward();
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getPageSource());
		String actualtitle = driver.getTitle();
		String expectedTitle = "MyEMailForm";
		if(actualtitle.contentEquals(expectedTitle))
		{
			System.out.println("Title Matches!!");
		}
		else
		{
			System.out.println("Title doesn't match !!!");
		}
		if(driver.getPageSource().contains("Email Registration"))
		{
			System.out.println("Expected Heading is present !!!");
		}
		else
		{
			System.out.println("Expected heading is not present!!");
		}
	}

}
