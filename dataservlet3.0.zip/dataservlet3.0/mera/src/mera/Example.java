package mera;

import java.util.*;
import java.util.concurrent.TimeUnit;





//import java.awt.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

public class Example 
{
	 public static void main(String[] args) throws Exception
	 {
		 WebDriver driver = new FirefoxDriver();
		 driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html");
		 //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// Thread.sleep(30000);
		 
		 System.out.println(driver.findElement(By.tagName("h1")).getText());
		 System.out.println(driver.findElement(By.xpath("html/body/form/table/tbody/tr[4]/td[1]")).getText());
		 driver.findElement(By.name("txtUName")).sendKeys("Smith12");
		 Thread.sleep(1000);
		 driver.findElement(By.id("txtPassword")).sendKeys("1234");
		 Thread.sleep(1000);
		 driver.findElement(By.className("Format")).sendKeys("12345");
		 Thread.sleep(1000);
		driver.findElement(By.id("txtFirstName")).click();
		driver.switchTo().alert().accept();
		
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

				WebElement ele = wait.until(new Function<WebDriver, WebElement>()
				{

				public WebElement apply(WebDriver driver)

				            {         

				WebElement element = driver.findElement(By.xpath("html/body/form/table/tbody/tr[2]/td[1]"));

				String getTextOnPage = element.getText();

				if(getTextOnPage.equals("Password :"))

				{

				System.out.println(getTextOnPage);

				return element;

				}                                             

				else

				{

				System.out.println("FluentWait Failed");

				                        return null;

				}}

				});

		
		/*try
		 {
		 WebDriverWait wait = new WebDriverWait(driver, 15);
		 wait.until(ExpectedConditions.alertIsPresent());
		 System.out.println(driver.switchTo().alert().getText());
		 }
		 catch(Exception e)
			{
				System.out.println(e);
			}*/
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.className("Format")).clear();
		 driver.findElement(By.id("txtPassword")).sendKeys("1234");
		driver.findElement(By.className("Format")).sendKeys("1234");
		driver.findElement(By.xpath("//*[@id='txtFirstName']")).sendKeys("Smith");
		 
		 System.out.println(driver.findElement(By.xpath("//*[@id='txtFirstName']")).getAttribute("value"));
		 
		 Thread.sleep(1000);
		 driver.findElement(By.name("txtLN")).sendKeys("Jones");
		 Thread.sleep(1000);
		 
		 if(driver.findElement(By.name("gender")).isSelected())
		 {
			 System.out.println("Gender is selected");
		 }
		 else
		 {
			 System.out.println("Gender is not selected");
		 }
		 driver.findElements(By.name("gender")).get(1).click();
		 Thread.sleep(1000);
		 if(driver.findElement(By.id("rbMale")).isSelected())
		 {
			 driver.findElement(By.id("rbFemale")).click();
		 }
		 else
		 {
			 driver.findElement(By.id("rbMale")).click();
		 }
		 driver.findElement(By.xpath("//*[@id='DOB']")).sendKeys("10-10-1998");
		 Thread.sleep(1000);
		 driver.findElement(By.name("Email")).sendKeys("smith12@gmail.com");
		 Thread.sleep(1000);
		 driver.findElement(By.id("txtAddress")).sendKeys("M.G.Road ,Thane");
		 Thread.sleep(1000);
		 Select drpCity = new Select(driver.findElement(By.name("City")));
		 List<WebElement> e = drpCity.getOptions();
		 System.out.println("Count of elements :" + e.size());
		  
		 if(drpCity.isMultiple())
		 {
			 drpCity.selectByVisibleText("Mumbai");
			 Thread.sleep(1000);
			 drpCity.selectByIndex(1);
			 Thread.sleep(1000);
			 drpCity.selectByValue("Bangalore");
			 Thread.sleep(1000);
		 }
		 
		 if(driver.findElement(By.id("txtUserName")).isDisplayed())
		 {
			 System.out.println("Username is displayed !!!");
		 }
		 else
		 {
			 System.out.println("Username is not displayed !!!");
		 }
		 
		 driver.findElement(By.id("txtPhone")).sendKeys("9988776655");
		 Thread.sleep(1000);
		 driver.findElements(By.name("chkHobbies")).get(0).click();
		 Thread.sleep(1000);
		 driver.findElements(By.name("chkHobbies")).get(1).click();
		 Thread.sleep(1000);
		/* List<WebElement> element = driver.findElements(By.name("chkHobbies"));
		 for(WebElement val : element)
		 {
			 val.click();
			 Thread.sleep(1000);
		 }*/
		 driver.findElement(By.name("submit")).click();
		 Thread.sleep(1000);
		 //driver.findElement(By.linkText("Click Me")).click();
		 driver.findElement(By.partialLinkText("Click")).click();
		 
		 driver.close();
	 } 
}
