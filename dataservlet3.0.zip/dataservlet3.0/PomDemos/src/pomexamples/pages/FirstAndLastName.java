package pomexamples.pages;

import org.openqa.selenium.*;

public class FirstAndLastName 
{
	WebDriver driver;
	
	/*String lname;
	String uname; 
	
	
	
	public FirstAndLastName(WebDriver driver)
	{
		this.driver = driver;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}
	*/
	
	By Uname = By.name("txtUName");
	By ln = By.name("txtLN");
	
	public FirstAndLastName(WebDriver driver)
	{
		this.driver = driver;
	}

	public By getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		 driver.findElement(this.Uname).sendKeys(uname);
	}

	public By getLn() {
		return ln;
	}

	public void setLn(String ln) {
		driver.findElement(this.ln).sendKeys(ln);
	}

	 
	
	
}
