package pomexamples.pages;

 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPageFactory 
{
	WebDriver driver;
	
	@FindBy(id="txtUserName")
	@CacheLookup
	WebElement uname;
	
	@FindBy(how = How.NAME, using="txtLN")
	@CacheLookup
	WebElement ln;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement pass;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement confpass;

	
	public LoginPageFactory(WebDriver driver) 
	{
			this.driver = driver;
	}

	public void setUname(String uname) {
		 this.uname.sendKeys(uname);
	}

	public void setLn(String ln) {
		this.ln.sendKeys(ln);
	} 

	public void setPass(String pass) {
		this.pass.sendKeys(pass);
	} 

	public void setConfpass(String confpass) {
		this.confpass.sendKeys(confpass);
	}
	
	public void PassConfPass(String pass , String cpass)
	{
		this.pass.clear();
		this.confpass.clear();
		this.pass.sendKeys(pass);
		this.confpass.sendKeys(cpass);
	}
	
	 
	 
}
