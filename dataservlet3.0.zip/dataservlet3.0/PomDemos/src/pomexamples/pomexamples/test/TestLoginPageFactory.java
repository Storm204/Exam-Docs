package pomexamples.pomexamples.test;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pomexamples.pages.LoginPageFactory;

public class TestLoginPageFactory 
{
  @Test
  public void verifyloginpagefactory() throws Exception 
  {
	  WebDriver driver = new FirefoxDriver();
	  driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html ");
	  LoginPageFactory f1 = PageFactory.initElements(driver, LoginPageFactory.class);
	  
	  f1.setUname("ABC");
	  Thread.sleep(1000);
	  f1.setLn("XYZ");
	  Thread.sleep(1000);
	  f1.setPass("12345");
	  Thread.sleep(1000);
	  f1.setConfpass("123455");
	  Thread.sleep(1000);
	  driver.findElement(By.id("txtFirstName")).click();
	  Thread.sleep(1000);
	  System.out.println(driver.switchTo().alert().getText());
	  driver.switchTo().alert().accept();
	  Thread.sleep(1000);
	 /* driver.findElement(By.id("txtPassword")).clear();
	  Thread.sleep(1000);
	  driver.findElement(By.id("txtConfPassword")).clear();
	  Thread.sleep(1000);
	 f1.setPass("12345");
	  Thread.sleep(1000);
	  f1.setConfpass("12345");
	  Thread.sleep(1000);
	  */
	  f1.PassConfPass("12345", "12345");
	  driver.findElement(By.id("txtFirstName")).sendKeys("PQR");
	  
	  
	  //driver.close();
  }
}
