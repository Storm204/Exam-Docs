package pomexamples.pomexamples.test;

import java.io.File;
import java.io.FileInputStream;

import org.dom4j.*;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestPropertyXml 
{
 @Test
 public void TestXml() throws Exception
 {
	 	File src = new File("./Configurations/ObjectRepository.xml");
		FileInputStream fls = new FileInputStream(src); 
		
		SAXReader saxReader = new SAXReader();
		Document document = saxReader.read(fls);
		
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html");
		
		driver.findElement(By.id(document.selectSingleNode("//login_detail/uname").getText())).sendKeys("John");
		Thread.sleep(1000);
		driver.findElement(By.id(document.selectSingleNode("//login_detail/pass").getText())).sendKeys("12345");
		Thread.sleep(1000);
 }
}
