package pomexamples.pomexamples.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestOR 
{
	@Test
	public void TestConfig() throws Exception
	{
		File src = new File("./Configurations/WorkingWithForms.property"); //to access the file
		FileInputStream fls = new FileInputStream(src); 
		Properties pro = new Properties();
		pro.load(fls);
		
		WebDriver driver = new FirefoxDriver();
		 
		driver.get(pro.getProperty("url"));
		
		driver.findElement(By.id(pro.getProperty("username"))).sendKeys("Capgemini");
		Thread.sleep(1000);
		driver.findElement(By.id(pro.getProperty("password"))).sendKeys("Capgemini");
		Thread.sleep(1000);
		
	}
}
