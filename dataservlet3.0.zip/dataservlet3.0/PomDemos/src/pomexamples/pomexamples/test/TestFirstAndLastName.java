package pomexamples.pomexamples.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import pomexamples.pages.FirstAndLastName;


public class TestFirstAndLastName 
{
	
	
  @Test
  	public void verifylogin() 
  	{
	  WebDriver driver = new FirefoxDriver();
	  driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html");
	  FirstAndLastName f = new FirstAndLastName(driver);
	  f.setUname("ABC");
	  f.setLn("XYZ");
  	}
}
