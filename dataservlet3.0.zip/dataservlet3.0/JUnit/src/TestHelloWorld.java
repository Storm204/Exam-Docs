import static org.junit.Assert.*;

import org.junit.Test;


public class TestHelloWorld 
{
	@Test
	public void TestSayHello()
	{
		HelloWorld hello = new HelloWorld();
		assertEquals("Hello World! ",hello.SayHello());
	}
}
