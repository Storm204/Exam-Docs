import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class TestWorkingWithForms  
{
	static WebDriver driver;
	
	@BeforeClass
	public static void openBrowser()
	{
		System.out.println("In Before");
		driver = new FirefoxDriver();
		
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/AdvanceSelenium/WorkingWithForms.html");
		
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
	}
	
	public void TestTitle()
	{
		String title = driver.getTitle();
		assertEquals("Your Store",title);
	}
	
	@Test
	public void TestAlert()
	{
		 driver.findElement(By.id("txtPassword")).sendKeys("1234");
		 driver.findElement(By.className("Format")).sendKeys("12345");
		driver.findElement(By.id("txtFirstName")).click();
		driver.switchTo().alert().accept();
	}
	
	@Test
	public void TestHeading()
	{
		String searchText = driver.findElement(By.xpath("html/body/form/table/tbody/tr[4]/td[1]")).getText();
		assertTrue(searchText.contains("First Name :"));
	}
	
	@After
	public void closeBrowser()
	{
		System.out.println("In After");
		
	}
	
	@AfterClass
	public static void nullDriver()
	{
		System.out.println("driver is null");
		driver.quit();
		driver = null;
	}
}
