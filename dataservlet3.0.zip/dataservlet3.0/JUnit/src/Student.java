
public class Student 
{
	int RollNo;
	String FirstName;
	String LastName;
	
	Student(int rollNo, String firstName ,String lastName)
	{
		RollNo = rollNo;
		FirstName = firstName ;
		LastName = lastName ;
	}

	public String getFirstName() 
	{
		return FirstName;
	}

	public int getRollNo() 
	{
		return RollNo;
	}

	public String getLastName() 
	{
		return LastName;
	}

}
