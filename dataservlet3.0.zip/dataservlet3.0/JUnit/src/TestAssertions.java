import static org.junit.Assert.*;

import org.junit.*;


public class TestAssertions 
{
	@Test
	public void testAssertions()
	{
		String str1 = new String("abc");
		String str2 = new String("abc");
		String str3 = null;
		String str4 = "abc";
		String str5 = "abc";
		
		int val1 =5;
		int val2 = 6;
		
		String[] expectedArray = {"one" , "two" ,"three" };
		String[] resultArray = {"one" , "two" , "three"};
		
		assertEquals(str1, str2); //checks string objects are equal
		
		assertTrue(val1 < val2); //checks whether condition is true
		
		assertFalse(val1 > val2); //checks whether condition is false
		
		assertNotNull(str1); //checks that object isn't null
		
		assertNull(str3); //checks for null object
		
		assertSame(str4 , str5); //checks if two object point to same object
		
		assertNotSame(str1 , str3); //checks if two object not point to same object
		
		assertArrayEquals(expectedArray ,resultArray); //checks that two arrays are equal
	}
}
