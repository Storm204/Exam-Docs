import static org.junit.Assert.*;

import org.junit.*;
 


public class TestStudent 
{
	Student s1 = new Student(101, "Alexandra","Barone");
	
	@Test
	public void xyz()
	{
		//assertEquals(1,101);
		System.out.println("xyz method");
	}
	
	@Test
	public void abc()
	{
		//assertEquals(s1.getFirstName(),"Alexandra");
		System.out.println("abc method");
	}
	@Ignore("abc")
	@Test
	public void GetLastName()
	{
		assertEquals(s1.getLastName(),"Barone");
	}
	
	@Before
	public void BeforeTest()
	{
		System.out.println("Before each Test");
	}
	
	@BeforeClass
	public static void BeforeClass()
	{
		System.out.println("Before Class");
	}
	
	@After
	public void after()
	{
		System.out.println("Aftr each test");
	}
	
	@AfterClass
	public static void AfterClass()
	{
		System.out.println("After class");
	}
}
